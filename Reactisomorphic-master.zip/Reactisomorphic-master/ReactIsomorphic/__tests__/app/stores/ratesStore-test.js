describe("The Rates Store",()=>{
	
});